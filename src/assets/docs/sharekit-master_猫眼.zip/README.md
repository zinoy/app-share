ShareKit
=============

### Example
```js
// create instance .
var kit = new ShareKit()
// create share content
kit.share({
  title: 'Hello World!',
  content: '我每每看见人真是虚心谦卑的时候，我就不禁想到“压伤的芦苇它不折断，将残的灯火它不吹灭”这一教示。—— 马太福音',
  image: 'http://api.lsong.org/qr?text=hello',
  url: 'http://blog.lsong.org',
})
.content('sms', 'test')
// share channels .
.to('sms,wechat');

```

## API

```clang
typedef enum {
    //oauth2
    MTShareMethodSinaWeibo = 1 << 0,     //新浪微博
    MTShareMethodQzone = 1 << 1,         //qq空间
    MTShareMethodQQWeibo = 1 << 2,       //腾讯微博
    MTShareMethodRenren = 1 << 3,        //人人网
    MTShareMethodKaixin = 1 << 4,        //开心网
    //app
    MTShareMethodSMS = 1 << 5,           //短信
    MTShareMethodEmail = 1 << 6,         //邮件
    MTShareMethodWeixin = 1 << 7,        //微信
    MTShareMethodWeixinFriends = 1 << 8, //微信朋友圈
    MTShareMethodQQClient = 1 << 9,      //qq
    MTShareMethodAll = ~0,               //所有渠道
}MTShareMethod;
```

### Contributing
- Fork this Repo first
- Clone your Repo
- Install dependencies by `$ npm install`
- Checkout a feature branch
- Feel free to add your features
- Make sure your features are fully tested
- Publish your local branch, Open a pull request
- Enjoy hacking <3

### MIT license
Copyright (c) 2015 lsong

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the &quot;Software&quot;), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED &quot;AS IS&quot;, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

---
