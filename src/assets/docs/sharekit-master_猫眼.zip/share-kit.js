/**
 * [function ShareKit]
 * @param  {[object]}   options [配置参数]
 * @return {[instance]}         [对象实例]
 */
var ShareKit = function(options){
  var defaults = {
    api: 'imeituan://www.meituan.com/share'
  };
  for(var key in options){
    defaults[key] = options[key];
  }
  this.options = defaults;
  return this;
};
/**
 * [channels 分享渠道]
 * weibo:0,sms: 5, wc: 7, 8:cir
 * @type {Object}
 */
ShareKit.channels = {
  WEIBO  : 0x01 << 0x00,
  QZONE  : 0x01 << 0x01,
  TENCENT: 0x01 << 0x02,
  RENREN : 0x01 << 0x03,
  KAIXIN : 0x01 << 0x04,
  SMS    : 0x01 << 0x05,
  EMAIL  : 0x01 << 0x06,
  WECHAT : 0x01 << 0x07,
  MOMENTS: 0x01 << 0x08,
  QQ     : 0x01 << 0x09
};
/**
 * [function 生成 URL 参数]
 * @param  {[object]} obj [params]
 * @return {[string]}     [like a=1&b=2]
 */
ShareKit.prototype.params = function(obj){
    var params = [ ];
    for(var key in obj){
        params.push([ key, encodeURIComponent(obj[key]) ].join('='));
    }
    return params.join('&');
};
/**
 * [function 生成分享数据]
 * @param  {[object]} data [分享数据]
 * @return {[instance]}      [对象实例]
 */
ShareKit.prototype.share = function(data){
    data = data || {};
    this.options.shareData = {
        'title'      : data.title   || '',
        'imageURL'   : data.image   || '',
        'detailURL'  : data.url     || ''
    };
    if(data.content){
        this.options.shareData[ 'content_-1' ] = data.content;
    }
    return this;
};
/**
 * [function description]
 * @param  {[type]} channel [description]
 * @param  {[type]} conetnt [description]
 * @return {[type]}         [description]
 */
ShareKit.prototype.content = function(channel, content){
    var _this = this;
    var setContent = function(cha, con){
        var c = ShareKit.channels[ cha.toUpperCase() ];
        _this.options.shareData[ 'content_' + c ] = con;
    }
    if(content){
        setContent(channel,content);
    }else if(typeof channel == "object"){
        for (var k in channel){
            setContent(k,channel[k]);
        }
    }
    if(channel){
        var defaultContent = _this.options.shareData[ 'content_-1' ];
        delete _this.options.shareData[ 'content_-1' ];
        for(var k in ShareKit.channels){
            var v = ShareKit.channels[ k ];
            if(!_this.options.shareData[ 'content_' + v ]){
                _this.options.shareData[ 'content_' + v ] =  defaultContent;
            }
        }
    }
    return this;
};
/**
 * [function 分享到渠道]
 * @param  {[string|array|object]} channel [渠道名称]
 * @return {[instance]}         [对象实例]
 */
ShareKit.prototype.to = function(channel){
    switch(typeof channel){
        case 'string':
            channel = channel.split(',');
        case 'object':
            var c, key;
            for(var i in channel){
                key = channel[i].toUpperCase();
                c = c | ShareKit.channels[ key.trim() ];
            }
            channel = c;
            break;
        case 'undefined':
            channel = ~0; //all
            break;
    }
    this.options.shareData.channel = channel;
    var params = this.params(this.options.shareData);
    var shareUrl = [this.options.api, params ].join('?');
    window.location.href = shareUrl;
};
/**
 * [ShareKit]
 * @type {[type]}
 */
if (typeof define === 'function' && define.amd) {
    define([], function() {
        return ShareKit;
    });
} else if (typeof module!=='undefined' && module.exports) {
    module.exports = ShareKit;
} else {
    this.ShareKit = ShareKit;
}
